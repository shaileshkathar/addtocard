import express from "express";
import login from "../controller/authcontrolller.js";
import { createuser } from "../controller/usercontroller.js";

const router = express.Router();

router.route("/reg").post(createuser);
router.route("/login").post(login);

export default router;
