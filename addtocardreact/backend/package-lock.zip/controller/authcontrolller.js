import user from "../model/usermodel.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const login = async (req, res) => {
  try {
    // console.log(req.body);
    const { email, password } = req.body;
    const result = await user.findOne({
      where: {
        email,
      },
    });
    // console.log(result);
    if (!result) {
      return res.status(401).json({
        success: false,
        massage: "email not found",
      });
    }

    const verify = bcrypt.compare(password, result.password);
    // console.log(verify);

    if (!verify) {
      return res.status(401).json({
        success: false,
        massage: "please enter valid password",
        data: null,
      });
    }
    const token = jwt.sign({ id: result._id }, "jwt");
    // const role = result.role;
    // const permission = await permissionmapping.findAll({
    //   where: {
    //     role,
    //   },
    // });
    // console.log(permission);
    res.json({
      success: true,
      massage: "you are log in",
      result: {
        email: result.email,

        id: result._id,
        firstname: result.firstname,
        lastname: result.lastname,
        email: result.email,

        // role: result.role,
      },
      token,
    });
  } catch (error) {
    res.status(401).json({
      success: false,
      massage: "something went wrong",
    });
  }
};
export default login;
