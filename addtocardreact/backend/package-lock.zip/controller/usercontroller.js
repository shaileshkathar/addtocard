import user from "../model/usermodel.js";
import bcrypt from "bcryptjs";

export const createuser = async (req, res) => {
  try {
    const salt = await bcrypt.genSalt(12);
    const hash = await bcrypt.hash(req.body.password, salt);
    const result = await user.create({ ...req.body, password: hash });
    res.json({
      message: "user Created",
      result,
    });
  } catch (error) {
    res.json({ message: error.message });
  }
};
