import {
  applyMiddleware,
  combineReducers,
  legacy_createStore as createstore,
} from "redux";
import thunk from "redux-thunk";
import { composeWithDevTools } from "redux-devtools-extension";
import { addtocartreducers } from "./reducers/addtocartreducer";

const rootReducers = combineReducers({
  addtocart: addtocartreducers,
});
const store = createstore(
  rootReducers,
  {},
  composeWithDevTools(applyMiddleware(thunk))
);

export default store;
