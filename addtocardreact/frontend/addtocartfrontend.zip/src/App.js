import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Headers from "./components/Headers";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "./pages/Home";
import Cards from "./components/Cards";
import "react-toastify/dist/ReactToastify.css";
import CardDetails from "./components/CardDetails";
import { useRef } from "react";

function App() {
  const mainRef = useRef(null);
  return (
    <>
      <BrowserRouter>
        <Headers mainRef={mainRef} />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/cards" element={<Cards mainRef={mainRef} />} />
          <Route path="/carts/:id" element={<CardDetails />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
