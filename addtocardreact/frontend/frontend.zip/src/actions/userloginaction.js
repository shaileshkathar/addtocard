import axios from "axios";
import {
  USER_LOGIN_FAIL,
  USER_LOGIN_LOGOUT,
  USER_LOGIN_REQUEST,
  USER_LOGIN_SUCCESS,
} from "../constants/loginconstant";

export const userlogin = (logdata) => async (dispatch) => {
  try {
    dispatch({ type: USER_LOGIN_REQUEST });
    const { data } = await axios.post(
      "http://localhost:5000/api/v1/login",
      logdata
    );
    console.log(data.result);
    dispatch({ type: USER_LOGIN_SUCCESS, payload: data.result });
    localStorage.setItem("token", JSON.stringify(data.result));
  } catch (error) {
    dispatch({ type: USER_LOGIN_FAIL, payload: error });
  }
};

export const userlogout = () => (dispatch) => {
  dispatch({ type: USER_LOGIN_LOGOUT });
  localStorage.removeItem("token");
};
